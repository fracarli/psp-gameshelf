Corresponding source: https://github.com/fracarli/psp-gameshelf
Clone with --recurse-submodules and apply the included patches inside matching
submodules at the recorded upstream commits. Shared headers belong in the
parent project. Build commands: patches/README.md. Each runtime retains its
upstream terms and has source/license references alongside its executable.
PicoDrive is the unmodified upstream PSP 2.05 release with its original license.
