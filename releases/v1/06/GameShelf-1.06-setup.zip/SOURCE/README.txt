Corresponding emulator source: https://github.com/fracarli/psp-gameshelf
Clone with --recurse-submodules; use the recorded upstream commits.
Apply the included patches inside the matching submodules.
TempGBA also requires SOURCE/shared/gba_identity.h in the parent project.
NesterJ: https://github.com/PSP-Archive/NesterJ-AoEX
TempGBA: https://github.com/GrabowskiDev/TempGBA4PSP-Single-game
